package com.example.fragmentslifecycle;

public interface Communicator {
    void passData(String data);
}
