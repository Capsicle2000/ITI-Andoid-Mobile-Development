package com.example.datastorage;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

public class MainActivity extends AppCompatActivity {

    private EditText mobileNumber;
    private EditText message;
    private Button readSharedPref;
    private Button writeSharedPref;
    private Button reset;
    private Button closeButton;
    private Button writeFile;
    private Button readFile;
    private DatabaseAdapter databaseAdapter;
    private Button insert;
    private Button select;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mobileNumber = findViewById(R.id.mobileNumberValue);
        message = findViewById(R.id.messageValue);

        reset = findViewById(R.id.reset);
        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                message.setText("");
                mobileNumber.setText("");
            }
        });

        writeFile = findViewById(R.id.file_w);
        writeFile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String mobileNumberValue = mobileNumber.getText().toString();
                String messageValue = message.getText().toString();
                try {
                    FileOutputStream fileOutputStream = openFileOutput("data.txt", MODE_PRIVATE);
                    OutputStreamWriter outputStreamWriter = new OutputStreamWriter(fileOutputStream);
                    outputStreamWriter.write(mobileNumberValue + "\n" + messageValue);
                    outputStreamWriter.close();
                    Toast.makeText(MainActivity.this, "Data saved successfully to file", Toast.LENGTH_SHORT).show();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });

        readFile = findViewById(R.id.file_r);
        readFile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                try {
                    FileInputStream fileInputStream = openFileInput("data.txt");
                    InputStreamReader inputStreamReader = new InputStreamReader(fileInputStream);
                    BufferedReader bufferedReader = new BufferedReader(inputStreamReader);
                    String mobileNumberValue = bufferedReader.readLine();
                    String messageValue = bufferedReader.readLine();
                    bufferedReader.close();
                    mobileNumber.setText(mobileNumberValue);
                    message.setText(messageValue);
                    Toast.makeText(MainActivity.this, "Data loaded successfully from file", Toast.LENGTH_SHORT).show();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });

        writeSharedPref = findViewById(R.id.sh_w);
        writeSharedPref.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String text = message.getText().toString();
                String mobileNum = mobileNumber.getText().toString();
                writeSharedPref(text,mobileNum);
            }
        });

        readSharedPref = findViewById(R.id.sh_r);
        readSharedPref.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferences sharedPreferences = getSharedPreferences("sharedPref", MODE_PRIVATE);
                String text = sharedPreferences.getString("message", "");
                String mobileNum = sharedPreferences.getString("mobileNumber", "");
                message.setText(text);
                mobileNumber.setText(mobileNum);
                Toast.makeText(MainActivity.this, "Data Loaded successfully from SH_Pref.", Toast.LENGTH_SHORT).show();
            }
        });

        closeButton = findViewById(R.id.closeButton);
        closeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });


        databaseAdapter = new DatabaseAdapter(this);
        databaseAdapter.open();
        insert = findViewById(R.id.insert);
        insert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                storeData();
            }
        });

        select = findViewById(R.id.select);
        select.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                retrieveData();
            }
        });
    }

    private void storeData() {
        String mobile_value = mobileNumber.getText().toString().trim();
        String message_value = message.getText().toString().trim();

        long id = databaseAdapter.insertData(mobile_value, message_value);

        if (id != -1) {
            Toast.makeText(this, "Data stored successfully", Toast.LENGTH_SHORT).show();
            mobileNumber.setText("");
            message.setText("");
        } else {
            Toast.makeText(this, "Error storing data", Toast.LENGTH_SHORT).show();
        }
    }
    private void retrieveData() {
        String[] columns = {DatabaseAdapter.COLUMN_MOBILE, DatabaseAdapter.COLUMN_MESSAGE};
        String orderBy = "ROWID DESC";
        Cursor cursor = databaseAdapter.getAllData(columns, orderBy, "1");

        if (cursor != null && cursor.moveToFirst()) {
            int mobileIndex = cursor.getColumnIndex(DatabaseAdapter.COLUMN_MOBILE);
            int messageIndex = cursor.getColumnIndex(DatabaseAdapter.COLUMN_MESSAGE);

            if (mobileIndex != -1 && messageIndex != -1) {
                String mobile_value = cursor.getString(mobileIndex);
                String message_value = cursor.getString(messageIndex);

                mobileNumber.setText(mobile_value);
                message.setText(message_value);
            } else {
                Toast.makeText(this, "Column not found in the database", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "No data found in the database", Toast.LENGTH_SHORT).show();
        }

        if (cursor != null) {
            cursor.close();
        }
    }
    private void writeSharedPref(String message, String mobileNumber) {
        SharedPreferences sharedPreferences = getSharedPreferences("sharedPref", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("message", message);
        editor.putString("mobileNumber", mobileNumber);
        editor.commit();
        Toast.makeText(MainActivity.this, "Data saved successfully to SH_Pref.", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        databaseAdapter.close();
    }
}